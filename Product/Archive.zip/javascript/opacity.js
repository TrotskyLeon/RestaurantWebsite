$(window).scroll(function(){
    "use strict"; $(".caption").css("opacity", 1 - $(window).scrollTop() / 250);
  });

$(window).scroll(function(){
    "use strict"; $(".res").css("opacity", 9.8 - $(window).scrollTop() / 250);
  });